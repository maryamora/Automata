/*
    Passed by: Mary Danielle C. Amora
    All functions by: Mary Danielle C. Amora
    Groupmates (discussion of solution):
                                            > Michael Loewe Alivio
                                            > Paul Christian Kiunisala
                                            > Michael Jimro Quiambao
    References: my notes :)
*/
public class Grammar {

    public static void main(String[] args) {
        GrammarChecker grammarChecker = new GrammarChecker();
        grammarChecker.process();
        System.out.println("Process Finished.");
    }

}
