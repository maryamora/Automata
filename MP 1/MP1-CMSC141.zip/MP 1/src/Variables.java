import java.util.ArrayList;

public class Variables {

    String type = "";
    String variable = "";

    public Variables(){

    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVariable() {
        return variable;
    }

    public void setVariable(String variable) {
        this.variable = variable;
    }
}
